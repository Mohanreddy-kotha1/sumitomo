# Orchestration (PoC pointers) — Mohan

For PoC we keep it simple, no heavy IaC/CI-CD.

**Eventing (S3 → Glue):**
1. S3 event notification (PUT) on `s3://sumitomo-bronze-<env>/<table>/f1_raw/` to EventBridge.
2. EventBridge rule targets Step Functions *or* a Lambda that kicks the appropriate Glue job with args:
   - Bronze job: `raw_to_bronze_<table>` → `--table_id <table>`
   - On success, trigger Silver job for same table.
   - After all silver jobs succeed, trigger Gold metrics build.
3. Optional SNS on failure for PoC.

**Power BI refresh:**
- After Gold completes, invoke a small Lambda to call Power BI REST API to refresh dataset (if using DirectQuery over Athena, this may be unnecessary; if Import mode, trigger refresh).

**Athena exposure:**
- All Delta tables are registered in Glue Catalog in the respective DBs (`sumitomo_bronze_*`, `sumitomo_silver_*`, `sumitomo_gold_*`).
- Configure Power BI → Athena connector → select Workgroup and Catalog → pick tables.

_This note is intentionally brief to keep infra light for PoC._
