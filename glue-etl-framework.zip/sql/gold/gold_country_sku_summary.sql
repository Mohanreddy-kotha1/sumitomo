-- Mohan: Country x SKU summary for reporting
-- Params expected: SILVER_DB, GOLD_DB

CREATE DATABASE IF NOT EXISTS {GOLD_DB};

CREATE OR REPLACE TEMP VIEW v_sales AS
SELECT country_code, sku, qty, sales_amount, CAST(txn_date AS DATE) AS txn_date
FROM {SILVER_DB}.fact_sales;

CREATE TABLE IF NOT EXISTS {GOLD_DB}.rpt_country_sku_summary
USING delta
AS SELECT * FROM v_sales WHERE 1=0;

MERGE INTO {GOLD_DB}.rpt_country_sku_summary AS t
USING (
  SELECT
    country_code,
    sku,
    SUM(qty)          AS total_qty,
    SUM(sales_amount) AS total_sales,
    COUNT(*)          AS txn_cnt
  FROM v_sales
  GROUP BY country_code, sku
) AS s
ON t.country_code = s.country_code AND t.sku = s.sku
WHEN MATCHED THEN UPDATE SET
  t.total_qty   = s.total_qty,
  t.total_sales = s.total_sales,
  t.txn_cnt     = s.txn_cnt
WHEN NOT MATCHED THEN INSERT (country_code, sku, total_qty, total_sales, txn_cnt)
VALUES (s.country_code, s.sku, s.total_qty, s.total_sales, s.txn_cnt)
;
