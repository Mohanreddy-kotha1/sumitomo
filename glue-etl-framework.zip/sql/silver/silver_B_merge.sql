-- Mohan: Build/merge Fact for Sales from Bronze.B
-- Params expected: BRONZE_DB, SILVER_DB

CREATE DATABASE IF NOT EXISTS {SILVER_DB};

CREATE OR REPLACE TEMP VIEW v_src_fact_sales AS
SELECT
  country_code,
  sku,
  qty,
  sales_amount,
  txn_date,
  current_timestamp() AS dw_load_ts
FROM {BRONZE_DB}.B;

CREATE TABLE IF NOT EXISTS {SILVER_DB}.fact_sales
USING delta
AS SELECT * FROM v_src_fact_sales WHERE 1=0;

MERGE INTO {SILVER_DB}.fact_sales AS t
USING v_src_fact_sales AS s
ON t.country_code = s.country_code
 AND t.sku         = s.sku
 AND t.txn_date    = s.txn_date
WHEN MATCHED THEN UPDATE SET
  t.qty          = s.qty,
  t.sales_amount = s.sales_amount,
  t.dw_load_ts   = s.dw_load_ts
WHEN NOT MATCHED THEN INSERT *
;
