-- Mohan: Build/merge Dimension for Products from Bronze.A
-- Params expected: BRONZE_DB, SILVER_DB

CREATE DATABASE IF NOT EXISTS {SILVER_DB};

CREATE OR REPLACE TEMP VIEW v_src_dim_product AS
SELECT
  product_id,
  product_name,
  category,
  brand,
  price,
  country_code,
  current_timestamp() AS dw_load_ts
FROM {BRONZE_DB}.A;

CREATE TABLE IF NOT EXISTS {SILVER_DB}.dim_product
USING delta
AS SELECT * FROM v_src_dim_product WHERE 1=0;

MERGE INTO {SILVER_DB}.dim_product AS t
USING v_src_dim_product AS s
ON t.product_id = s.product_id AND t.country_code = s.country_code
WHEN MATCHED THEN UPDATE SET
  t.product_name = s.product_name,
  t.category     = s.category,
  t.brand        = s.brand,
  t.price        = s.price,
  t.dw_load_ts   = s.dw_load_ts
WHEN NOT MATCHED THEN INSERT *
;
