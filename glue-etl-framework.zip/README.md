# Sumitomo — Glue ETL Framework (Metadata‑Driven)  
Author: **Mohan Reddy Pallav (MP)** · Generated on 2025-09-09 06:01:05 UTC

This is my PoC codebase for a Glue + Delta Lake, metadata‑driven ELT over Excel sources with Bronze → Silver → Gold.  
Design centers on **YAML configs**, **schema enforcement**, **reusable utilities**, **custom JSON logging to S3 (central-logs)**, and **SQL-first modeling** for Silver/Gold.

> Buckets (PoC):  
> • `s3://sumitomo-bronze-<env>` · raw & bronze delta  
> • `s3://sumitomo-silver-<env>` · silver delta  
> • `s3://sumitomo-gold-<env>` · gold delta  
> • `s3://sumitomo-central-logs-<env>` · central JSON logs

---

## 1. Repo layout (top-level)

```
glue-etl-framework/
├── config/
│   ├── raw_to_bronze.yaml
│   ├── bronze_to_silver.yaml
│   ├── silver_to_gold.yaml
│
├── schema_definitions/
│   ├── A_schema.json
│   ├── B_schema.json
│
├── sql/
│   ├── silver/
│   │   ├── silver_A_merge.sql
│   │   ├── silver_B_merge.sql
│   ├── gold/
│   │   ├── gold_country_sku_summary.sql
│
├── jobs/
│   ├── bronze/
│   │   ├── raw_to_bronze_A.py
│   │   ├── raw_to_bronze_B.py
│   ├── silver/
│   │   ├── bronze_to_silver_A.py
│   │   ├── bronze_to_silver_B.py
│   ├── gold/
│   │   ├── silver_to_gold_country_summary.py
│
├── framework/
│   ├── __init__.py
│   ├── spark_session.py
│   ├── logger.py
│   ├── metadata_parser.py
│   ├── utils.py
│   ├── transformations.py
│   ├── delta_writer.py
│
├── orchestration/
│   ├── README.md
│
├── requirements_glue.txt
└── tests/.gitkeep
```

---

## 2. Glue job parameters (what I actually use)

**Glue 4.0** · Python 3.10. Sample additional modules (tuned for PoC):

```
--additional-python-modules delta-spark==2.4.0,PyYAML==6.0.1,openpyxl==3.1.2,pandas==2.2.2,boto3==1.34.162,awswrangler==3.8.0
```

Spark configs (either via job parameters `--conf` or set in `spark_session.py`):

```
--conf spark.sql.extensions=io.delta.sql.DeltaSparkSessionExtension
--conf spark.sql.catalog.spark_catalog=org.apache.spark.sql.delta.catalog.DeltaCatalog
--conf spark.serializer=org.apache.spark.serializer.KryoSerializer
--conf spark.sql.sources.partitionOverwriteMode=dynamic
--conf spark.databricks.delta.schema.autoMerge.enabled=true
--conf spark.sql.legacy.timeParserPolicy=LEGACY
--enable-glue-datacatalog
```

**Bronze (Excel → CSV → Delta)**

```
--JOB_NAME raw_to_bronze_A
--env dev
--config s3://<code-bucket>/glue-etl-framework/config/raw_to_bronze.yaml
--table_id A
--run_id 20250909T000001Z
```

**Silver**

```
--JOB_NAME bronze_to_silver_A
--env dev
--config s3://<code-bucket>/glue-etl-framework/config/bronze_to_silver.yaml
--table_id A
--run_id 20250909T000201Z
```

**Gold**

```
--JOB_NAME silver_to_gold_country_summary
--env dev
--config s3://<code-bucket>/glue-etl-framework/config/silver_to_gold.yaml
--metric country_sku_summary
--run_id 20250909T000401Z
```

> In PoC, I package this repo as a zip and upload to an S3 **code bucket**, then point Glue jobs to the entry scripts in `jobs/`.

---

## 3. Mapping to the task sheet
- **Metadata structure in YAML** → `config/*.yaml` (WK1–WK3, Owner: Mohan/Pallav)
- **Reusable utilities** → `framework/*.py` (logging to central-logs, S3 I/O, delta helpers, schema) (WK1–WK3)
- **Core framework components** → `spark_session.py`, `metadata_parser.py`, `transformations.py`, `delta_writer.py` (WK1–WK3)
- **Bronze jobs** → `jobs/bronze/*.py` (WK4–WK5)
- **Silver jobs** → `jobs/silver/*.py` & `sql/silver/*.sql` (WK4–WK5)
- **Gold jobs** → `jobs/gold/*.py` & `sql/gold/*.sql` (WK4–WK5)
- **Orchestration & notifications** → `orchestration/README.md` (WK5, SNS/EventBridge pointers)
- **Athena/Power BI** → register Delta in Glue Catalog (see `delta_writer.register_table`), then use Athena connector in PBI.

---

## 4. Local dev note
These scripts are Glue-friendly but also runnable on local Spark for quick checks (limits: Excel handling via pandas). For Glue, make sure the **additional modules** above are set and IAM has S3 + Glue permissions.

