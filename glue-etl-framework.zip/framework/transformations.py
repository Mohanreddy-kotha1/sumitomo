# Author: Mohan Reddy Pallav (MP)
# Purpose: Common DF transforms — header mapping, normalization, dedupe, audit cols

from typing import Dict, List, Sequence
from pyspark.sql import DataFrame, Window
from pyspark.sql import functions as F

def apply_header_map(df: DataFrame, header_map: Dict[str, str]) -> DataFrame:
    out = df
    for src, tgt in header_map.items():
        if src in out.columns and tgt != src:
            out = out.withColumnRenamed(src, tgt)
    return out

def to_snake_case(df: DataFrame) -> DataFrame:
    def snake(s: str) -> str:
        s = s.strip().replace(" ", "_").replace("-", "_")
        return "".join([c.lower() if c.isalnum() or c == "_" else "_" for c in s])
    out = df
    for c in df.columns:
        sc = snake(c)
        if sc != c:
            out = out.withColumnRenamed(c, sc)
    return out

def add_audit_cols(df: DataFrame, source_name: str, run_id: str) -> DataFrame:
    return (
        df
        .withColumn("dw_created_ts", F.current_timestamp())
        .withColumn("dw_run_id", F.lit(run_id))
        .withColumn("dw_source", F.lit(source_name))
    )

def dedupe(df: DataFrame, keys: Sequence[str], order_by_cols: Sequence[str] = ("dw_created_ts",)) -> DataFrame:
    if not keys:
        return df
    w = Window.partitionBy(*[F.col(k) for k in keys]).orderBy(*[F.col(c).desc_nulls_last() for c in order_by_cols])
    return df.withColumn("_rn", F.row_number().over(w)).filter(F.col("_rn") == 1).drop("_rn")
