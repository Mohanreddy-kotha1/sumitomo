# Author: Mohan Reddy Pallav (MP)
# Purpose: Load YAML job configs & schema definitions, with ${ENV} substitution.

from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional
import yaml, os
from .utils import load_text, deep_update

@dataclass
class TableConfig:
    table_id: str
    source_type: str
    raw_path: str
    csv_path: str
    delta_path: str
    schema_path: str
    header_map: Dict[str, str] = field(default_factory=dict)
    dedupe_keys: List[str] = field(default_factory=list)
    partition_cols: List[str] = field(default_factory=list)
    options: Dict[str, Any] = field(default_factory=dict)

@dataclass
class RawToBronzeConfig:
    env: str
    logs_bucket: str
    bronze_db: str
    default_sheet: Optional[str] = None
    tables: List[TableConfig] = field(default_factory=list)

def _subst_env(val: Any, env: str) -> Any:
    if isinstance(val, str):
        return val.replace("${ENV}", env)
    if isinstance(val, list):
        return [_subst_env(x, env) for x in val]
    if isinstance(val, dict):
        return {k: _subst_env(v, env) for k, v in val.items()}
    return val

def load_yaml(path: str) -> dict:
    text = load_text(path)
    return yaml.safe_load(text)

def load_raw_to_bronze(path: str, overrides: Optional[dict] = None) -> RawToBronzeConfig:
    y = load_yaml(path)
    if overrides:
        y = deep_update(y, overrides)
    env = y.get("env", os.environ.get("env", "dev"))
    y = _subst_env(y, env)
    tables = [TableConfig(**t) for t in y.get("tables", [])]
    return RawToBronzeConfig(
        env=env,
        logs_bucket=y["logs_bucket"],
        bronze_db=y["bronze_db"],
        default_sheet=y.get("default_sheet"),
        tables=tables
    )

@dataclass
class SqlJob:
    table_id: Optional[str] = None
    sql_file: str = ""
    target_table: Optional[str] = None
    partition_cols: List[str] = field(default_factory=list)

@dataclass
class BronzeToSilverConfig:
    env: str
    bronze_db: str
    silver_db: str
    jobs: List[SqlJob]

def load_bronze_to_silver(path: str, overrides: Optional[dict] = None) -> BronzeToSilverConfig:
    y = load_yaml(path)
    if overrides:
        y = deep_update(y, overrides)
    env = y.get("env", os.environ.get("env", "dev"))
    y = _subst_env(y, env)
    jobs = [SqlJob(**j) for j in y.get("jobs", [])]
    return BronzeToSilverConfig(env=env, bronze_db=y["bronze_db"], silver_db=y["silver_db"], jobs=jobs)

@dataclass
class SilverToGoldConfig:
    env: str
    silver_db: str
    gold_db: str
    metrics: List[SqlJob]

def load_silver_to_gold(path: str, overrides: Optional[dict] = None) -> SilverToGoldConfig:
    y = load_yaml(path)
    if overrides:
        y = deep_update(y, overrides)
    env = y.get("env", os.environ.get("env", "dev"))
    y = _subst_env(y, env)
    metrics = [SqlJob(**m) for m in y.get("metrics", [])]
    return SilverToGoldConfig(env=env, silver_db=y["silver_db"], gold_db=y["gold_db"], metrics=metrics)
