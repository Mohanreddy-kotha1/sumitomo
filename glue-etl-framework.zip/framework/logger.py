# Author: Mohan Reddy Pallav (MP)
# Purpose: JSON logger that writes to CloudWatch AND a central S3 logs bucket.

import atexit, json, logging, os, uuid, datetime
from typing import Optional
try:
    import boto3  # Glue runtime
except Exception:
    boto3 = None

class _S3JsonBufferHandler(logging.Handler):
    def __init__(self, s3_uri: Optional[str]):
        super().__init__()
        self.s3_uri = s3_uri
        self.buffer = []

    def emit(self, record: logging.LogRecord) -> None:
        payload = {
            "ts": datetime.datetime.utcnow().isoformat(timespec="seconds") + "Z",
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        self.buffer.append(json.dumps(payload))

    def flush_to_s3(self):
        if not self.s3_uri or not self.buffer:
            return
        if boto3 is None:
            return
        s3 = boto3.client("s3")
        if not self.s3_uri.startswith("s3://"):
            return
        # s3://bucket/prefix
        _, rest = self.s3_uri.split("s3://", 1)
        bucket, key_prefix = rest.split("/", 1)
        key = key_prefix.rstrip("/") + f"/part-{uuid.uuid4().hex}.json"
        body = "\n".join(self.buffer).encode("utf-8")
        s3.put_object(Bucket=bucket, Key=key, Body=body, ContentType="application/json")
        self.buffer = []

def get_logger(job_name: str, env: str, logs_bucket_s3: Optional[str] = None) -> logging.Logger:
    logger = logging.getLogger(f"{job_name}")
    if not logger.handlers:
        logger.setLevel(logging.INFO)
        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)
        fmt = logging.Formatter("%(asctime)s %(levelname)s [%(name)s] %(message)s")
        ch.setFormatter(fmt)
        logger.addHandler(ch)
        s3_uri = None
        if logs_bucket_s3:
            # s3://central-logs/env/glue/<job_name>/dt=YYYY-MM-DD/run_id=<run>/
            run_id = os.environ.get("run_id", datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ"))
            today = datetime.date.today().isoformat()
            s3_uri = f"{logs_bucket_s3}/glue/{job_name}/env={env}/dt={today}/run_id={run_id}"
        s3h = _S3JsonBufferHandler(s3_uri)
        logger.addHandler(s3h)
        # expose flush for callers
        logger.s3_flush = s3h.flush_to_s3  # type: ignore[attr-defined]
    return logger
