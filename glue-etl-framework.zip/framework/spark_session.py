# Author: Mohan Reddy Pallav (MP)
# Purpose: Central SparkSession builder for Glue & local. Delta & Glue Catalog ready.

from typing import Tuple, Optional
import os

def get_spark(app_name: str = None):
    """Get a SparkSession configured for Delta + Glue Catalog, both in Glue & local runs.

    Returns: (spark, glue_ctx, job_or_none)
    """
    app = app_name or os.environ.get("JOB_NAME", "glue-etl")
    try:
        # Glue runtime
        from pyspark import SparkContext
        from awsglue.context import GlueContext
        from awsglue.job import Job
        sc = SparkContext.getOrCreate()
        glue_ctx = GlueContext(sc)
        spark = glue_ctx.spark_session
        # Baseline configs (Glue job can also pass through --conf)
        spark.conf.set("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
        spark.conf.set("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
        spark.conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
        spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
        spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
        try:
            job = Job(glue_ctx)
        except Exception:
            job = None
        return spark, glue_ctx, job
    except Exception:
        # Local dev
        from pyspark.sql import SparkSession
        builder = (
            SparkSession.builder.appName(app)
            .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
            .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
            .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
            .config("spark.sql.sources.partitionOverwriteMode", "dynamic")
            .enableHiveSupport()
        )
        spark = builder.getOrCreate()
        return spark, None, None
