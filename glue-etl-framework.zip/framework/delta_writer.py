# Author: Mohan Reddy Pallav (MP)
# Purpose: Delta IO helpers — write, merge/upsert, register in Glue Catalog

from typing import List, Dict
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

def write_delta(df: DataFrame, path: str, mode: str = "append", partition_cols: List[str] = None):
    w = df.write.format("delta").mode(mode)
    if partition_cols:
        w = w.partitionBy(*partition_cols)
    w.save(path)

def register_table(spark: SparkSession, db: str, table: str, location: str):
    spark.sql(f"CREATE DATABASE IF NOT EXISTS {db}")
    spark.sql(f"""CREATE TABLE IF NOT EXISTS {db}.{table}
              USING delta
              LOCATION '{location}'""")

def merge_upsert(spark: SparkSession, df: DataFrame, delta_path: str, key_cols: List[str]):
    from delta.tables import DeltaTable
    if not key_cols:
        raise ValueError("key_cols required for merge_upsert")
    dt = DeltaTable.forPath(spark, delta_path)
    tgt = dt.alias("t")
    src = df.alias("s")
    on_expr = " AND ".join([f"t.{k}=s.{k}" for k in key_cols])
    set_map = {c: F.col(f"s.{c}") for c in df.columns}
    dt.alias("t").merge(src, on_expr).whenMatchedUpdate(set=set_map).whenNotMatchedInsert(values=set_map).execute()
