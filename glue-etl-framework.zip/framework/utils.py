# Author: Mohan Reddy Pallav (MP)
# Purpose: S3 helpers, schema helpers, small utilities I keep reusing

import io, json, os, re
from typing import Dict, Any, Tuple
try:
    import boto3
except Exception:
    boto3 = None

from pyspark.sql.types import (
    StructType, StructField, StringType, IntegerType, LongType, DoubleType,
    BooleanType, DateType, TimestampType, DecimalType
)

_S3_RE = re.compile(r'^s3://([^/]+)/(.+)$')

def parse_s3_uri(uri: str) -> Tuple[str, str]:
    m = _S3_RE.match(uri)
    if not m:
        raise ValueError(f"Invalid s3 uri: {uri}")
    return m.group(1), m.group(2)

def load_text(path: str) -> str:
    if path.startswith("s3://"):
        if boto3 is None:
            raise RuntimeError("boto3 not available in local run for S3 access")
        b, k = parse_s3_uri(path)
        s3 = boto3.client("s3")
        obj = s3.get_object(Bucket=b, Key=k)
        return obj["Body"].read().decode("utf-8")
    else:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()

def save_text(path: str, text: str) -> None:
    if path.startswith("s3://"):
        if boto3 is None:
            raise RuntimeError("boto3 not available")
        b, k = parse_s3_uri(path)
        s3 = boto3.client("s3")
        s3.put_object(Bucket=b, Key=k, Body=text.encode("utf-8"))
    else:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(text)

def json_to_spark_type(t: str):
    t = t.lower()
    if t in ("string",): return StringType()
    if t in ("int","integer"): return IntegerType()
    if t in ("long","bigint"): return LongType()
    if t in ("double","float","number"): return DoubleType()
    if t in ("bool","boolean"): return BooleanType()
    if t in ("date",): return DateType()
    if t in ("timestamp","datetime"): return TimestampType()
    if t.startswith("decimal"):
        # decimal(18,2), etc.
        m = re.match(r"decimal\((\d+),(\d+)\)", t)
        if m: return DecimalType(int(m.group(1)), int(m.group(2)))
        return DecimalType(38, 18)
    return StringType()

def schema_from_json_text(schema_json: str) -> StructType:
    j = json.loads(schema_json)
    fields = j.get("fields", [])
    struct_fields = [StructField(f["name"], json_to_spark_type(f["type"]), True) for f in fields]
    return StructType(struct_fields)

def deep_update(base: Dict[str, Any], overrides: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(base)
    for k, v in overrides.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_update(out[k], v)
        else:
            out[k] = v
    return out
