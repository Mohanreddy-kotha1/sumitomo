# Glue entry: silver_to_gold_country_summary
# Mohan: Build Gold aggregated table(s) via SQL

import os, sys
from framework.spark_session import get_spark
from framework.logger import get_logger
from framework.metadata_parser import load_silver_to_gold
from framework.utils import load_text

def main():
    args = dict(zip(sys.argv[1::2], sys.argv[2::2]))
    env = args.get("--env", os.environ.get("env", "dev"))
    os.environ["env"] = env
    os.environ["run_id"] = args.get("--run_id", "manual")
    metric = args.get("--metric", "country_sku_summary")
    cfg = load_silver_to_gold(args["--config"])
    job_name = f"silver_to_gold_{metric}"
    logger = get_logger(job_name, env, logs_bucket_s3=None)
    spark, _, _ = get_spark(job_name)

    m = next(m for m in cfg.metrics if m.target_table and m.sql_file and m.sql_file.endswith("country_sku_summary.sql"))
    sql = load_text(m.sql_file).format(SILVER_DB=cfg.silver_db, GOLD_DB=cfg.gold_db)
    logger.info(f"Executing SQL for metric={metric}")
    spark.sql(sql)
    logger.info("Gold SQL execution complete.")
    logger.s3_flush()

if __name__ == "__main__":
    main()
