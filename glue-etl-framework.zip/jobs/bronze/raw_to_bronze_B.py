# Glue entry: raw_to_bronze_B
# Thin wrapper to reuse A logic by switching --table_id

import os, sys
from jobs.bronze.raw_to_bronze_A import main as main_impl

if __name__ == "__main__":
    # Forward to the same implementation, but keep job_name distinct
    # Expect Glue args: --env --config --run_id
    if "--table_id" not in sys.argv:
        sys.argv += ["--table_id", "B"]
    main_impl()
