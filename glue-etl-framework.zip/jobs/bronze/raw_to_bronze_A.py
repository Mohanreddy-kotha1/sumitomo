# Glue entry: raw_to_bronze_A
# Mohan: Excel→CSV→Delta (Table A)

import os, sys, io
from pyspark.sql import functions as F
from pyspark.sql.types import StructType
from framework.spark_session import get_spark
from framework.logger import get_logger
from framework.metadata_parser import load_raw_to_bronze
from framework.utils import parse_s3_uri, load_text, schema_from_json_text
from framework.transformations import apply_header_map, to_snake_case, add_audit_cols, dedupe
from framework.delta_writer import write_delta, register_table

try:
    import pandas as pd
    import boto3
except Exception:
    pd = None
    boto3 = None

def main():
    # Glue passes --env, --config, --table_id, --run_id
    args = dict(zip(sys.argv[1::2], sys.argv[2::2]))
    env = args.get("--env", os.environ.get("env", "dev"))
    os.environ["env"] = env
    table_id = args.get("--table_id", "A")
    os.environ["run_id"] = args.get("--run_id", "manual")
    cfg = load_raw_to_bronze(args["--config"])
    job_name = f"raw_to_bronze_{table_id}"
    logger = get_logger(job_name, env, cfg.logs_bucket)

    spark, glue_ctx, job = get_spark(job_name)
    logger.info(f"Starting {job_name} env={env}")

    # pick table metadata
    t = next(t for t in cfg.tables if t.table_id == table_id)
    # Excel -> CSV (folder-2) if needed
    if t.source_type.lower() == "excel":
        if pd is None or boto3 is None:
            raise RuntimeError("pandas/openpyxl + boto3 required for Excel conversion in Glue")
        s3 = boto3.client("s3")
        b_raw, k_prefix = parse_s3_uri(t.raw_path)
        # Convert each .xlsx under raw_path prefix to CSV in csv_path
        paginator = s3.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=b_raw, Prefix=k_prefix):
            for obj in page.get("Contents", []):
                key = obj["Key"]
                if not key.lower().endswith((".xlsx", ".xls")):
                    continue
                # read excel into pandas
                bin_body = s3.get_object(Bucket=b_raw, Key=key)["Body"].read()
                sheet_name = t.options.get("sheet_name") or cfg.default_sheet
                df = pd.read_excel(io.BytesIO(bin_body), sheet_name=sheet_name, engine="openpyxl")
                # rename JP headers to English
                df.rename(columns=t.header_map, inplace=True)
                # write to csv_path with same basename
                base = os.path.basename(key).rsplit(".", 1)[0] + ".csv"
                b_csv, k_csv_prefix = parse_s3_uri(t.csv_path)
                out_key = f"{k_csv_prefix.rstrip('/')}/{base}"
                csv_bytes = df.to_csv(index=False).encode("utf-8")
                s3.put_object(Bucket=b_csv, Key=out_key, Body=csv_bytes, ContentType="text/csv")
                logger.info(f"Converted Excel → CSV: s3://{b_csv}/{out_key}")

    # Read CSVs into Spark with enforced schema
    schema_text = load_text(t.schema_path)
    schema: StructType = schema_from_json_text(schema_text)
    df = (
        spark.read.format("csv")
        .option("header", True)
        .schema(schema)
        .load(t.csv_path)
    )

    # Transformations: header map (for any leftover cols), snake_case, audit, dedupe
    df = apply_header_map(df, t.header_map)
    df = to_snake_case(df)
    df = add_audit_cols(df, source_name=f"{table_id}", run_id=os.environ["run_id"])
    df = dedupe(df, keys=t.dedupe_keys)

    # Write to Delta (folder-3) and register table in Glue Catalog
    write_delta(df, t.delta_path, mode="append", partition_cols=t.partition_cols)
    register_table(spark, cfg.bronze_db, table_id, t.delta_path)

    logger.info(f"Wrote Delta: {t.delta_path} and registered {cfg.bronze_db}.{table_id}")
    logger.s3_flush()

if __name__ == "__main__":
    main()
