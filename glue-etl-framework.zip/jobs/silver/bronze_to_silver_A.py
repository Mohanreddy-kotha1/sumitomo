# Glue entry: bronze_to_silver_A
# Mohan: Executes parameterized SQL to build/merge Silver dim/fact from Bronze

import os, sys
from framework.spark_session import get_spark
from framework.logger import get_logger
from framework.metadata_parser import load_bronze_to_silver
from framework.utils import load_text

def main():
    args = dict(zip(sys.argv[1::2], sys.argv[2::2]))
    env = args.get("--env", os.environ.get("env", "dev"))
    os.environ["env"] = env
    os.environ["run_id"] = args.get("--run_id", "manual")
    table_id = args.get("--table_id", "A")
    cfg = load_bronze_to_silver(args["--config"])
    job_name = f"bronze_to_silver_{table_id}"
    logger = get_logger(job_name, env, logs_bucket_s3=None)  # logs go to CloudWatch for this job
    spark, _, _ = get_spark(job_name)

    job = next(j for j in cfg.jobs if j.table_id == table_id)
    sql = load_text(job.sql_file).format(BRONZE_DB=cfg.bronze_db, SILVER_DB=cfg.silver_db)
    logger.info(f"Executing SQL for table_id={table_id}")
    spark.sql(sql)
    logger.info("SQL execution complete.")
    logger.s3_flush()

if __name__ == "__main__":
    main()
