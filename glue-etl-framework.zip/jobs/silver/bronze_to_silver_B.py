# Glue entry: bronze_to_silver_B (wrapper)
import sys
from jobs.silver.bronze_to_silver_A import main as main_impl

if __name__ == "__main__":
    if "--table_id" not in sys.argv:
        sys.argv += ["--table_id", "B"]
    main_impl()
